# PHP Functions and Form Exercises

This folder contains 12 runnable exercises: three on PHP functions and all
nine practical labs from Lesson 4 (Form Handling and Basic Web Security).

## Functions

1. `Functions/Exercise1.php` — enter three scores, validate them, and calculate the average and result.
2. `Functions/Exercise2.php` — enter width and height, validate them, and calculate rectangle area.
3. `Functions/Exercise3.php` — enter student name, age, and city, validate them, and safely display the information.

## Forms and basic web security

1. `Form/Lab4.1.php` — GET search and escaped output.
2. `Form/Lab4.2.php` — POST name/phone form and validation.
3. `Form/Lab4.3.php` — escape an HTML/script string.
4. `Form/Lab4.4.php` — validate required name and email.
5. `Form/Lab4.5.php` — sticky text field and validated select.
6. `Form/Lab4.6.php` — sticky checkbox array with allowed-value validation.
7. `Form/Lab4.7.php` — Post/Redirect/Get with a one-time session message.
8. `Form/Lab4.8.php` — validated contact form using `filter_input()` and escaped output.
9. `Form/Lab4.9.php` — student registration with validation, sticky state, and PRG.

Run the PHP built-in web server from the repository root:

```text
php -S localhost:8000
```

Then open `http://localhost:8000/ExerciseLesson4/Form/Lab4.1.php` or any other exercise
path in a browser. Session-based labs require a web server; do not open PHP files
directly from the filesystem.
